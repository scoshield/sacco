<?php

namespace Modules\User\Filters;

class HasRoleFilter
{

}